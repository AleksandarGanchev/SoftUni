# Create an instance of SummitQuestManagerApp
